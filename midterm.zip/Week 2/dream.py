while True:
    events = []
    dreams = []
    scenarios = []
    num_of_events = int(input())
    
