n = int(input().strip())
m = int(input())

print(n, m)